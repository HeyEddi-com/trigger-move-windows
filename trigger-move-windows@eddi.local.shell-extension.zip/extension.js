'use strict';

/* exported init */

let Extension = null;

function init() {
  log('[trigger-move-windows] initializing');
  return Extension;
}

function enable() {
  log('[trigger-move-windows] enabling');
}

function disable() {
  log('[trigger-move-windows] disabling');
}
