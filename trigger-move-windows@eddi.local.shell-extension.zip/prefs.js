/* prefs.js
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Gtk from 'gi://Gtk';

import { ExtensionPreferences, gettext as _ } from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

export default class TriggerMoveWindowsPreferences extends ExtensionPreferences {
  fillPreferencesWindow(window) {
    const settings = this.getSettings();

    // Create main page
    const page = new Adw.PreferencesPage({
      title: _('Trigger Move Windows'),
      icon_name: 'preferences-desktop-keyboard-shortcuts',
    });
    window.add(page);

    // General Settings Group
    const generalGroup = new Adw.PreferencesGroup({
      title: _('General Settings'),
      description: _('Configure basic extension behavior'),
    });
    page.add(generalGroup);

    // Keyboard shortcut row
    const shortcutRow = new Adw.ActionRow({
      title: _('Keyboard Shortcut'),
      subtitle: _('Shortcut to trigger window movement'),
    });

    const shortcutButton = new Gtk.Button({
      label: this._getShortcutLabel(settings),
      valign: Gtk.Align.CENTER,
    });
    shortcutButton.connect('clicked', () => {
      this._showShortcutDialog(window, settings, shortcutButton);
    });
    shortcutRow.add_suffix(shortcutButton);
    generalGroup.add(shortcutRow);

    // Show notifications switch
    const notificationsRow = new Adw.SwitchRow({
      title: _('Show Notifications'),
      subtitle: _('Display desktop notifications when windows are moved'),
    });
    settings.bind('show-notifications', notificationsRow, 'active', Gio.SettingsBindFlags.DEFAULT);
    generalGroup.add(notificationsRow);

    // Skip correct workspace switch
    const skipCorrectRow = new Adw.SwitchRow({
      title: _('Skip Correctly Placed Windows'),
      subtitle: _('Don\'t move windows already on their target workspace'),
    });
    settings.bind('skip-correct-workspace', skipCorrectRow, 'active', Gio.SettingsBindFlags.DEFAULT);
    generalGroup.add(skipCorrectRow);

    // Debug logging switch
    const debugRow = new Adw.SwitchRow({
      title: _('Debug Logging'),
      subtitle: _('Enable debug output in system logs'),
    });
    settings.bind('debug-logging', debugRow, 'active', Gio.SettingsBindFlags.DEFAULT);
    generalGroup.add(debugRow);

    // Window Matching Group
    const matchingGroup = new Adw.PreferencesGroup({
      title: _('Window Matching'),
      description: _('Configure how windows are identified'),
    });
    page.add(matchingGroup);

    // Match by WM_CLASS
    const wmClassRow = new Adw.SwitchRow({
      title: _('Match by WM_CLASS'),
      subtitle: _('Use window class name for matching'),
    });
    settings.bind('match-by-wm-class', wmClassRow, 'active', Gio.SettingsBindFlags.DEFAULT);
    matchingGroup.add(wmClassRow);

    // Match by title
    const titleRow = new Adw.SwitchRow({
      title: _('Match by Window Title'),
      subtitle: _('Use window title for matching (partial match)'),
    });
    settings.bind('match-by-title', titleRow, 'active', Gio.SettingsBindFlags.DEFAULT);
    matchingGroup.add(titleRow);

    // Match by process
    const processRow = new Adw.SwitchRow({
      title: _('Match by Process Name'),
      subtitle: _('Use process name for matching'),
    });
    settings.bind('match-by-process', processRow, 'active', Gio.SettingsBindFlags.DEFAULT);
    matchingGroup.add(processRow);

    // Advanced Settings Group
    const advancedGroup = new Adw.PreferencesGroup({
      title: _('Advanced Settings'),
    });
    page.add(advancedGroup);

    // Max workspace spin button
    const maxWorkspaceRow = new Adw.SpinRow({
      title: _('Maximum Workspace'),
      subtitle: _('Maximum workspace number for window placement'),
      adjustment: new Gtk.Adjustment({
        lower: 1,
        upper: 36,
        step_increment: 1,
        page_increment: 5,
        value: settings.get_int('max-workspace'),
      }),
    });
    settings.bind('max-workspace', maxWorkspaceRow, 'value', Gio.SettingsBindFlags.DEFAULT);
    advancedGroup.add(maxWorkspaceRow);

    // Notification timeout spin button
    const timeoutRow = new Adw.SpinRow({
      title: _('Notification Timeout'),
      subtitle: _('How long to show notifications (seconds)'),
      adjustment: new Gtk.Adjustment({
        lower: 1,
        upper: 10,
        step_increment: 1,
        page_increment: 1,
        value: settings.get_int('notification-timeout'),
      }),
    });
    settings.bind('notification-timeout', timeoutRow, 'value', Gio.SettingsBindFlags.DEFAULT);
    advancedGroup.add(timeoutRow);

    // Application Configurations Group
    const appGroup = new Adw.PreferencesGroup({
      title: _('Application Configurations'),
      description: _('Configure which workspace each application should move to'),
    });
    page.add(appGroup);

    // App configurations list
    this._createAppConfigsList(appGroup, settings, window);
  }

  _getShortcutLabel(settings) {
    const shortcuts = settings.get_strv('trigger-shortcut');
    if (shortcuts.length === 0) {
      return _('Not set');
    }
    return shortcuts[0].replace('<Super>', 'Super+').replace('<Shift>', 'Shift+').replace('<', '').replace('>', '');
  }

  _showShortcutDialog(parent, settings, button) {
    const dialog = new Gtk.Dialog({
      title: _('Set Keyboard Shortcut'),
      transient_for: parent,
      modal: true,
      use_header_bar: 1,
    });

    const content = dialog.get_content_area();
    const label = new Gtk.Label({
      label: _('Press the key combination you want to use...'),
      margin_top: 20,
      margin_bottom: 20,
      margin_start: 20,
      margin_end: 20,
    });
    content.append(label);

    dialog.add_button(_('Cancel'), Gtk.ResponseType.CANCEL);
    dialog.add_button(_('Clear'), Gtk.ResponseType.REJECT);

    const eventController = new Gtk.EventControllerKey();
    dialog.add_controller(eventController);

    eventController.connect('key-pressed', (controller, keyval, keycode, state) => {
      const mask = state & Gtk.accelerator_get_default_mod_mask();

      if (mask === 0 || keyval === Gdk.KEY_Escape) {
        return false;
      }

      const shortcut = Gtk.accelerator_name(keyval, mask);
      settings.set_strv('trigger-shortcut', [shortcut]);
      button.label = this._getShortcutLabel(settings);
      dialog.response(Gtk.ResponseType.OK);
      return true;
    });

    dialog.connect('response', (dialog, response) => {
      if (response === Gtk.ResponseType.REJECT) {
        // Clear shortcut
        settings.set_strv('trigger-shortcut', []);
        button.label = this._getShortcutLabel(settings);
      }
      dialog.destroy();
    });

    dialog.show();
  }

  _createAppConfigsList(group, settings, window) {
    const appConfigs = this._parseAppConfigs(settings);

    // Create a scrolled window for the list
    const scrolled = new Gtk.ScrolledWindow({
      hscrollbar_policy: Gtk.PolicyType.NEVER,
      vscrollbar_policy: Gtk.PolicyType.AUTOMATIC,
      max_content_height: 300,
    });

    const listBox = new Gtk.ListBox({
      selection_mode: Gtk.SelectionMode.NONE,
    });
    listBox.add_css_class('boxed-list');
    scrolled.set_child(listBox);

    // Add existing configurations
    for (const [appName, workspace] of Object.entries(appConfigs)) {
      this._addAppConfigRow(listBox, settings, appName, workspace);
    }

    // Add button to add new configuration
    const addButton = new Gtk.Button({
      label: _('Add Application'),
      margin_top: 10,
      margin_bottom: 10,
      margin_start: 10,
      margin_end: 10,
    });
    addButton.add_css_class('suggested-action');
    addButton.connect('clicked', () => {
      this._showAddAppDialog(window, settings, listBox);
    });

    const appRow = new Adw.PreferencesRow();
    const box = new Gtk.Box({
      orientation: Gtk.Orientation.VERTICAL,
      margin_top: 10,
      margin_bottom: 10,
      margin_start: 10,
      margin_end: 10,
    });

    box.append(scrolled);
    box.append(addButton);
    appRow.set_child(box);
    group.add(appRow);
  }

  _addAppConfigRow(listBox, settings, appName, workspace) {
    const row = new Gtk.ListBoxRow();
    const box = new Gtk.Box({
      orientation: Gtk.Orientation.HORIZONTAL,
      spacing: 12,
      margin_top: 6,
      margin_bottom: 6,
      margin_start: 12,
      margin_end: 12,
    });

    const appLabel = new Gtk.Label({
      label: appName,
      hexpand: true,
      xalign: 0,
    });

    const workspaceSpinButton = new Gtk.SpinButton({
      adjustment: new Gtk.Adjustment({
        lower: 1,
        upper: settings.get_int('max-workspace'),
        step_increment: 1,
        value: workspace,
      }),
      valign: Gtk.Align.CENTER,
    });

    workspaceSpinButton.connect('value-changed', () => {
      this._updateAppConfig(settings, appName, workspaceSpinButton.get_value_as_int());
    });

    const removeButton = new Gtk.Button({
      icon_name: 'edit-delete-symbolic',
      valign: Gtk.Align.CENTER,
    });
    removeButton.add_css_class('destructive-action');
    removeButton.connect('clicked', () => {
      this._removeAppConfig(settings, appName);
      listBox.remove(row);
    });

    box.append(appLabel);
    box.append(workspaceSpinButton);
    box.append(removeButton);
    row.set_child(box);
    listBox.append(row);
  }

  _showAddAppDialog(parent, settings, listBox) {
    const dialog = new Adw.MessageDialog({
      heading: _('Add Application Configuration'),
      transient_for: parent,
    });

    const content = new Gtk.Box({
      orientation: Gtk.Orientation.VERTICAL,
      spacing: 12,
      margin_top: 12,
      margin_bottom: 12,
      margin_start: 12,
      margin_end: 12,
    });

    const appEntry = new Gtk.Entry({
      placeholder_text: _('Application name (e.g., firefox, chrome)'),
    });

    const workspaceSpinButton = new Gtk.SpinButton({
      adjustment: new Gtk.Adjustment({
        lower: 1,
        upper: settings.get_int('max-workspace'),
        step_increment: 1,
        value: 1,
      }),
    });

    const workspaceBox = new Gtk.Box({
      orientation: Gtk.Orientation.HORIZONTAL,
      spacing: 6,
    });
    workspaceBox.append(new Gtk.Label({
      label: _('Workspace:'),
    }));
    workspaceBox.append(workspaceSpinButton);

    content.append(appEntry);
    content.append(workspaceBox);
    dialog.set_extra_child(content);

    dialog.add_response('cancel', _('Cancel'));
    dialog.add_response('add', _('Add'));
    dialog.set_response_appearance('add', Adw.ResponseAppearance.SUGGESTED);

    dialog.connect('response', (dialog, response) => {
      if (response === 'add') {
        const appName = appEntry.get_text().trim();
        const workspace = workspaceSpinButton.get_value_as_int();

        if (appName) {
          this._updateAppConfig(settings, appName, workspace);
          this._addAppConfigRow(listBox, settings, appName, workspace);
        }
      }
      dialog.destroy();
    });

    dialog.show();
  }

  _parseAppConfigs(settings) {
    const configString = settings.get_string('app-configs');
    try {
      return JSON.parse(configString);
    } catch (error) {
      console.error('Error parsing app configs:', error);
      return {};
    }
  }

  _updateAppConfig(settings, appName, workspace) {
    const configs = this._parseAppConfigs(settings);
    configs[appName] = workspace;
    settings.set_string('app-configs', JSON.stringify(configs));
  }

  _removeAppConfig(settings, appName) {
    const configs = this._parseAppConfigs(settings);
    delete configs[appName];
    settings.set_string('app-configs', JSON.stringify(configs));
  }
}
